<?php

	// Defining Constants
	define( 'HOST', 'localhost' );
	define( 'DB', 'practice' );
	define( 'USER', 'root' );
	define( 'PASS', '' );
?>