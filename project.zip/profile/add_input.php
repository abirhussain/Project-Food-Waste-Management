<h1>Create Record</h1>



<form method=get action=add_result.php>

	name: <input type=text name=name> <br>

	<p>

	location: <input type=text name=location> <br>

	<p>

    number: <input type=text name=number><br>

	<p>

    email: <input type=text name=email><br>

	<input type=submit value=Insert>

</form>