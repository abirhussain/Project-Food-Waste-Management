<html>
<head>
<title>updation</title>
</head>
<body>
   <centr>

     <h1>update here</h1>

    <form action="" method="post">
       
       <input type="text" name="id" placeholder="enter id"/></br/>
       <input type="text" name="id" placeholder="enter id"/></br/>
       <input type="text" name="id" placeholder="enter id"/></br/>
       <input type="text" name="id" placeholder="enter id"/></br/>
       <input type="text" name="id" placeholder="enter id"/></br/>
       <input type="text" name="id" placeholder="enter id"/></br/>
       <input type="text" name="id" placeholder="enter id"/></br/>
       
       <input type="submit" name="update" value="update data ">

    </form>
    <centr/> 
</body>
</html>